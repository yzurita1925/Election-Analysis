# Election-Analysis
  
  Purpose of the project
  
  To automate the process to determne the folllowing:
  
    Report the total number of votes cast.
    Determine the total number of each candidate.
    Determine the porcentage of votes for each candidate
    Determine the winner of the elections on the popular vote. 
   
Resources 
  Data Source: election_results.csv
  Python software 3.10 and Visual Studio Code 
 
Elections Results

  There are 369,711 votes cast in the election.
  there were 3 counties involved in the elections.
    - Jefferson County
    - Arapahoe County
    - Denver County
    
The candidates are as follow:
    - Diana DeGette
    - Charles Gasper Stockham
    - Raymond Anthony Doane
    
The results for each county is as follow
    - Jefferson County received 38,855 votes which is 10.5% of the total votes.
    - Arapahoe County received 24,801 votes which is 6.7   of the total votes.
    - Denver County received 306,055 votes which is 82.8% of the total votes.
    
The results for each candidate is as follow
    - Diana DeGette received 272,892 votes which is 73.8 %
    - Charles Gasper received Stockham 85,213 votes which is 23%
    - Raymond Anthony Doane received 11,606 votes which is 3.1% 
    
The winner of the elections is Diana DeGette who received 272,892 votes.     

    
    
